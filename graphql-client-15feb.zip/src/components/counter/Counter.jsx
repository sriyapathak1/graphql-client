import React, { Component } from 'react';
import { Button } from '@material-ui/core';
class Counter extends Component {
    constructor(){
        super();
        this.state = {
            count: 0,
        };
    }
   formatCount = () => {
    const { count } = this.state;
    return count === 0 ? <h3>Zero</h3> : count;
   }  
    render() {
        return (
            <div>
                <span>{this.formatCount()}</span>
               <Button>Increment</Button> 
            </div>
        );
    }
}

export default Counter;
// https://my.visme.co/edit/5dfb933032c9e5aef8bdedb49f2c64e2
// https://www.slideshare.net/AikdanaiSidhikosol/react-hooks-101
// https://www.freecodecamp.org/news/lets-get-hooked-a-quick-introduction-to-react-hooks-9e8bc3fbaeac/
// 
// 