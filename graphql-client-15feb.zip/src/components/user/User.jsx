import React, { Component } from "react";
import axios from 'axios';
import { TextField } from '@material-ui/core';

export default class CreateStudent extends Component {

  constructor(props) {
    super(props)
    this.onChangeStudentEmail = this.onChangeStudentEmail.bind(this);
    // this.onChangeStudentRole = this.onChangeStudentRole.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    // Setting up state
    this.state = {
      email: '',
      role: ''
    }
  }
  onChangeStudentEmail(e) {
    this.setState({ email: e.target.value })
    console.log('fggggggggggggg', e.target);
    
  }

  onChangeRolo(e) {
    this.setState({ role: e.target.value })
    console.log('selected role is --', e.target);
    
  }

  onSubmit(e) {
    e.preventDefault()

    const studentObject = {
      email: this.state.email,
      role: this.state.role
    };
console.log('----studenjfhdui', studentObject);

    axios.post('http://localhost:2000/graphql', studentObject)
      .then(res => console.log(res.data));

    this.setState({
      email: '',
      role: ''
    });
  }

  render() {
    return (<div className="form-wrapper">
                       <form >
                       {/* <form  noValidate autoComplete="off"> */}
  <TextField id="outlined-basic" label="Email"
  variant="outlined" value={this.state.email} onChange={this.onChangeStudentEmail}  />
{/* </form> */}
                     <br /><br />
                     <label for="role">Select role : </label>
                      <select id="role" onChange={this.onChangeRolo}>
                        <option value="trainee">Trainee</option>
                        <option value="reviewer">Reviewer</option>
                        <option value="headTrainee">Head Trainee</option>
                      </select>
                      <br /><br />
                     <input type="submit" onClick={this.onSubmit} />
                 </form>
    </div>);
  }
}
