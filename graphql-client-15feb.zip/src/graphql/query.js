import gql from 'graphql-tag';
// import axios from 'axios';
// import client from '../apollo/Apollo';

// ... above is the instantiation of the client object.
// client
//   .query({
//     query: gql`
//       query getUser {
//         trainee
//       }
//     `
//   })
//   .then(result => console.log(result));

const GET_USER = gql`
query{
  getUser{
    data{
      trainee
      reviewer
    }
  }
}
`
export default GET_USER;
