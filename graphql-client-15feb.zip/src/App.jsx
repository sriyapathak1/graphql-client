import React from 'react';
// import Counter from './components/counter';
import { ApolloProvider } from '@apollo/react-hooks';
import client from './apollo/Apollo';
import User from './components/user/User';
import UserTable from './components/usertable/UserTable';

const App = () => 
{
  console.log('--------------', client);
return(
  
  
  <ApolloProvider client={client}>
    <div>
      <h2>My first Apollo app 🚀</h2>
      <User />
      <UserTable />
    </div>
  </ApolloProvider>
)};

// function App() {
//   return (
//     <div className="App">
//        <h1>Welcome</h1>
//        {/* <Counter /> */}
//        <User />
//     </div>
//   );
// }

export default App;
