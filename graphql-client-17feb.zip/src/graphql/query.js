import gql from 'graphql-tag';

const GET_USER = gql`
query{
  getUser{
    data{
      trainee
      reviewer
    }
  }
}
` 
export {
   GET_USER,
//  GET_PERMISSION,
};
