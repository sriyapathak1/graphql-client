const styles = () => ({
    formStyle: {
        padding: '0px',
        width: '100%',
        '& > div': {
        width: '100%',
        margin: '0 0 35px',
        },
        '& label': {
            
          },
          '& button': {
            width: '100%',
            padding: '15px',
        },
          },
    desc: {
      width: '50%',
      margin: '0 auto',
      padding: '15px',
    },
    btnText: {
      color: 'white',
      // margin: '0 auto',
      // padding: '15px',
    },
    paperStyle: {
      padding: '50px',
    display: 'flex',
    justifyContent: 'space-evenly',
      width: '50%',
      margin: '0 auto',
    }
    
  });

export default styles;
