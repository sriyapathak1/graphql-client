const styles = () => ({
    formStyle: {
        padding: '15px',
        '& > div': {
        width: '100%',
        margin: '0 0 35px',
        },
        '& label': {
            
          },
          '& button': {
            width: '100%',
            padding: '15px',
        },
          },
    desc: {
      width: '50%',
      margin: '0 auto',
      padding: '15px',
    },
    
  });

export default styles;
