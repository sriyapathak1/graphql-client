import React, { Component } from "react";
import { Link } from 'react-router-dom';
import axios from 'axios';
import * as yup from 'yup';
import { TextField, withStyles, Card, Button, FormLabel, Typography } from '@material-ui/core';
import style from './style';
import UserPermission from "../userPermision/UserPermission";


const errorMsg = {
  email: 'Email is required',
  role:'Role is required',
}
const Schema = yup.object().shape({
  // emailAddress: yup.string().email(errorMsg.email).required(),
  emailAddress: yup
      .string()
      .email()
      .required(),
      // role: yup.string().required(errorMsg.role),
});
 class User extends Component {

  constructor(props) {
    super(props)
    this.state = {
      role: '',
      currentValue: 'choose...',
      emailAddress: '',
      error: '',
      dataStore: 'validation',
    }
  }
  
  handleChange = field => (event) => {
    console.log('----email-validation-----', event.target);
    
    this.setState({[field]:event.target.value},
        () => this.handleValidate((field)));
}
handleStore = () => {
  const { dataStore } = this.state;
  if(dataStore){

  }
}
handleValidate = (e) => {
    const { emailAddress, role, dataStore } = this.state;
    console.log('------email state====', this.state);
    if(dataStore === 'validation' ){
    Schema.validate(
        {emailAddress},
        {abortEarly:false},
    )
    .then(() => {
      this.setState({
        role: '',
        currentValue: '',
        emailAddress: '',
        error: '',
        dataStore: '',
      })
        console.log('success');
    })
    .catch((error) => {
        console.log('email is not valid ', error);
    });
  } else{
    console.log('function -failed===/// ');
    
  }
  }

  onChangeRolo(e) {
    this.setState({ role: e.target.value })
    console.log('selected role is --', e.target);
    
  }

handleSubmit = evt => {
  const { emailAddress } = this.state;
  if (!this.canBeSubmitted()) {
    evt.preventDefault();
    return;
  }
};

canBeSubmitted() {
  const { emailAddress} = this.state;
  return emailAddress.length > 0 ;
}
  render() {
    const { classes } = this.props;
    const { currentValue, value, error, emailAddress } = this.state;
    const isEnabled = this.canBeSubmitted();
    console.log('=====isEnabled----', isEnabled);
    

    return (<div className={classes.desc}>
       <Card className={classes.root}>
        <form className={classes.formStyle} action="">
          <TextField id="outlined-basic" label="Email"
          variant="outlined"
          onBlur={this.handleValidate.emailAddress}
          // error={error.incudes(errorMsg.email)}
          required="required"
          helperText={<p>{error.includes(errorMsg) ? errorMsg: ''  }</p>}
          // value
          onChange={this.handleChange('emailAddress')}
          //  value={this.state.email} onChange={this.onChangeStudentEmail} 
           />
           <Typography>{}</Typography>
          
          <UserPermission />
          <Link to="/viewrole">
          <Button className={classes.btnText}
           variant="contained" color="secondary" 
           disabled={!isEnabled}
           onClick={this.handleValidate}>
            Submit
          </Button>
            </Link>
        </form>
      </Card>
        </div>);
  }
}
export default withStyles(style)(User);