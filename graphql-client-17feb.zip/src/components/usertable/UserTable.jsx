import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { GET_USER } from '../../graphql/query';
import CardTable from './CardTable';

class UserTable extends Component {
    render() {
        return (
           <Query query = {GET_USER}>
               {
                   ({loading, error, data}) => 
                   {
                       if(error) {
                           return "error while loading data"
                       } if(loading) {
                         return <h1>Loading............</h1>
                       }
                       if(data){
                        //    const dataArray= [];
                        //    dataArray.push(data);
                       console.log('-------data---', data.getUser.data);
                       return <CardTable data={data.getUser.data} />
                        } 
                    // return dataArray
                    // return data.getUser.data;
                   }
               }
           </Query>
        );
    }
}

export default UserTable;