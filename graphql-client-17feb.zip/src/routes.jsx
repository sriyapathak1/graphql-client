import React, { Component } from 'react';
import { Route } from 'react-router-dom';
// import UserTable from './components/userPermision/GetUserPermission';
import { Dashboard } from './modules';
import UserTable from './components/usertable/UserTable';
import CardTable from './components/usertable/CardTable';
import ViewRole from './modules/viewRole/ViewRole';


const AppRouter = () => (
    <div>
        <Route
        path="/"
        component={Dashboard}
        />
        <Route
        path="/list"
        component={CardTable}
        />
        <Route
        path="/viewrole"
        component={ViewRole}
        />
        {/* <Route
        path="/"
        component={Dashboard} */}
        {/* /> */}
    </div>
)


export default AppRouter;
